#include "Game.h"
#include <iostream>
#include <stdlib.h>

using namespace std;

int main(int argc, char** argv){
	Game::GetInstance()->Run();



	return 0;
}
